<div class="clear" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"
     xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
<div class="up_footer">
    <div class="main_upfooter">
        <div class="browse_pages">
            <p style="font-size: 13px;font-weight: bold; color: #d7d7d7;background: none">BROWSE PAGES</p>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About us</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Products</a></li>
                <li><a href="#">Contacts</a></li>
            </ul>
        </div>
        <div class="products_footer">
            <p style="font-size: 13px;font-weight: bold; color: #d7d7d7;text-transform: uppercase;">Products</p>
            <ul>
                <li><a href="#">Outsource</a></li>
                <li><a href="#">Website design</a></li>
                <li><a href="#">Web App</a></li>
                <li><a href="#">Outsource</a></li>
                <li><a href="#">Website design</a></li>
            </ul>
        </div>
        <div class="about_us">
            <p style="font-size: 13px; font-weight: bold; color: #d7d7d7; text-transform: uppercase">ABOUT US</p>
            <p style="margin-top: 22px">
                Themes is an incredibly powerful & fully responsive WordPress Theme. We use only core functions such as custom post types and shortcodes to make it easy for you to add and manage your content.
            </p>
        </div>
        <div class="with_us">
            <p style="font-size: 13px;color: #636363;font-weight: normal">
                <p style="font-size: 13px; font-weight: bold; color: #d7d7d7; text-transform: uppercase;margin-top: -5px;margin-left: 5px">GET IN TOUCH WITH US</p>
                <p style="margin-bottom: 13px; margin-left: 5px;margin-top: 21px">Pri precteque soleat est adolescens</br> theophrastus</p>
                <p style="font-size: 13px;font-weight: normal;color: #d7d7d7; margin-left: 5px">Grider all design service</p>
                <p style="margin-bottom: 10px; margin-left: 5px;margin-top: 2px">243/6 To Hien Thanh Street, Ward 14,</br> Dist. 10, HCM City</p>
                <p style="margin-left: 5px;margin-top: 12px">Phone: +848 123 4567</p>
                <p style="margin-left: 5px;margin-top: 2px">Fax: +848 123 4567</p>
                <p style="margin-left: 5px;margin-top: 1px">Email: name@enpii.com</p>
            </p>
        </div>



    </div>
</div>
<div class="down_footer" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
    <div class="main_footerdown">
        <p>Copyright © 2013 - Enpii. All Rights Reserved</p>
        <ul>
            <li><img src="<?php bloginfo('template_url'); ?>/images/face.png"></li>
            <li><img src="<?php bloginfo('template_url'); ?>/images/twitter.png"></li>
            <li><img src="<?php bloginfo('template_url'); ?>/images/googleplus.png"></li>
            <li><img src="<?php bloginfo('template_url'); ?>/images/linkle.png"></li>
            <li><img src="<?php bloginfo('template_url'); ?>/images/rss.png"></li>
        </ul>
    </div>
</div>
</div>

