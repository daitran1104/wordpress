<?php
/*
Plugin Name: string to upper the title
Plugin URI:localhost
Description: Auto upper title
Version: 1.0
Author: Tran Dai
Author URI: daitran1104@gmail.com
 */
add_filter('the_title','strtoupper');