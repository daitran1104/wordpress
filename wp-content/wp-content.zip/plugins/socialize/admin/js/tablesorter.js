// http://www.datatables.net/index

jQuery(document).ready(function($) { 
    $ ( "#metrics-table" ). tablesorter ();
}); 