=== Flickr Badges Widget ===
Contributors: zourbuth
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=W6D3WAJTVKAFC
Tags: Flickr, widget, badge, feed, photostream, javascript
Requires at least: 3.5
Tested up to: 3.3
Stable tag: 1.2

Display your Flickr latest photostream in widget area.

== Description ==

This is a simple widget to display your Flickr latest photostream in widget area using javascript from <code>http://www.flickr.com/badge_code_v2.gne</code>. 
Find your Flickr ID from (<a href="http://www.idgettr.com" target="_blank">idGettr</a> if you do not know your id. 
With its very beautiful widget interface, tabbed system, and powered by jQuery makes this plugin easier to customize. 
just put your Flickr ID and your widget will be ready to lunch. 

<h3>Installation</h3>
You can use the built in installer and upgrader, or you can install the plugin manually.<br />
1. Go to the menu 'Plugins' -> 'Install' and search for 'Flickr Badges Widget'.<br />
2. Click 'install'.

== Installation ==

You can use the built in installer and upgrader, or you can install the plugin manually.
1. Go to the menu 'Plugins' -> 'Install' and search for 'Flickr Badges Widget'
2. Click 'install'.

== Frequently Asked Questions ==

= A question that someone might have =

Please read the FAQ under http://zourbuth.com/plugins/flickr-badges-widget


== Screenshots ==

1. Widget Settings
2. Widget in frontend

== Changelog ==

= 1.0 =
* Released

== Upgrade Notice ==

= 1.0 =
Just upgrade via Wordpress.
